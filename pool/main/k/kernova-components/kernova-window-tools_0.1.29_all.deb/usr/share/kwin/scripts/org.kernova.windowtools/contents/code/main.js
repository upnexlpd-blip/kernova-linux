// Logical frame rectangles. Round shared edges once, keeping output offsets.
function rect(x, y, width, height) { return {x, y, width, height}; }
function copyRect(r) { return rect(r.x, r.y, r.width, r.height); }
function closeRect(a, b, tolerance = 1) {
    return ["x", "y", "width", "height"].every(k => Math.abs(a[k] - b[k]) <= tolerance);
}
function inside(r, a, tolerance = 0) {
    return r.width > 0 && r.height > 0 && r.x >= a.x - tolerance && r.y >= a.y - tolerance &&
        r.x + r.width <= a.x + a.width + tolerance && r.y + r.height <= a.y + a.height + tolerance;
}
function preset(kind, count, a, gap) {
    const coding = kind === "Coding";
    if (count !== (coding ? 3 : 2)) throw Error("Select exactly " + (coding ? 3 : 2) + " windows in slot order.");
    const width = Math.round((a.width - gap) * (coding ? 0.6 : 0.5));
    const right = a.width - gap - width;
    const x = a.x + width + gap;
    const top = Math.round((a.height - gap) / 2);
    const boxes = [rect(a.x, a.y, width, a.height), rect(x, a.y, right, coding ? top : a.height)];
    if (coding) boxes.push(rect(x, a.y + top + gap, right, a.height - gap - top));
    if (!boxes.every(r => inside(r, a))) throw Error("The configured gap does not fit this work area.");
    return boxes;
}
function normalize(r, a, tolerance = 0) {
    if (!inside(r, a, tolerance)) throw Error("Move each selected frame fully inside its output work area first.");
    const edges = [(r.x-a.x)/a.width, (r.y-a.y)/a.height, (r.x+r.width-a.x)/a.width, (r.y+r.height-a.y)/a.height];
    return edges.map(v => Math.max(0, Math.min(v, 1)));
}
function project(edges, a) {
    const [l,t,r,b] = edges.map((v,i) => {
        const extent = i % 2 ? a.height : a.width;
        return v === 1 ? extent : Math.min(extent, Math.round(v * extent));
    });
    return rect(a.x+l, a.y+t, r-l, b-t);
}
let selection = [];
let operation = null;
function area(output) {
    return copyRect(workspace.clientArea(KWin.MaximizeArea, output, workspace.currentDesktop));
}
function tolerance(output) {
    // At 125%, integer Wayland client sizes and physical decoration edges
    // can produce a 1.2 logical pixel discrepancy in the resulting frame.
    return output && !Number.isInteger(output.devicePixelRatio) ? 2 : 1;
}
function feedback(message) {
    callDBus("org.kde.plasmashell", "/org/kde/osdService", "org.kde.osdService",
        "showText", "preferences-system-windows", message);
}
function problem(w) {
    if (!w || w.deleted || !w.managed || !w.normalWindow || w.specialWindow || w.transient || w.modal ||
        String(w.resourceClass).toLowerCase().indexOf("kscreenlocker") >= 0)
        return "Select an ordinary application window.";
    if (w.fullScreen || w.maximizeMode !== 0 || w.tile || w.minimized || w.shade)
        return "Restore the window from fullscreen, maximize, tile, shade or minimize first.";
    if (w.move || w.resize || !w.moveable || !w.resizeable) return "This window must be movable and resizable.";
    if ((!w.onAllDesktops && w.desktops.indexOf(workspace.currentDesktop) < 0) ||
        (w.activities.length && w.activities.indexOf(workspace.currentActivity) < 0))
        return "The selection includes a window on another desktop or activity.";
    if (!w.output || workspace.screens.indexOf(w.output) < 0) return "The window's output is unavailable.";
    return "";
}
function checkedSelection() {
    if (!selection.length) throw Error("Add windows in slot order first.");
    selection.forEach(w => { const why = problem(w); if (why) throw Error(why); });
    return selection.slice();
}
function uniqueOutput(name) {
    const outputs = workspace.screens.filter(o => o.name === name);
    if (outputs.length !== 1) throw Error("Reconnect the saved output or save a new template on the current outputs.");
    return outputs[0];
}
function setting(key, fallback, min, max) {
    const n = Number(readConfig(key, fallback));
    return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
}
const actions = [
    ["Add","Add window to selection"], ["Remove","Remove window from selection"],
    ["Clear","Clear selection"], ["Inspect","Show selection order"],
    ["Side","Side by Side"], ["Coding","Coding layout"], ["Undo","Undo last layout"],
    ["Save","Save selection to template"], ["Load","Apply template"], ["List","List saved templates"],
    ["Delete","Delete template"], ["Reload","Reload saved settings"]
];
const templateBus = "org.kernova.WindowTemplates";
const tilers = ["krohnkite","bismuth","polonium","karousel","kwin-tiling"];
let pending = null;
const deadline = new QTimer();
deadline.singleShot = true;
deadline.interval = 3500;
deadline.timeout.connect(() => {
    pending = null;
    feedback("Window Tools timed out waiting for a session service. Check the selection or template before retrying.");
});
function finish(token) {
    if (pending === token) { deadline.stop(); pending = null; }
}
options.configChanged.connect(() => {
    if (pending && pending.reload) {
        finish(pending);
        feedback("Gap " + setting("Gap",8,0,64) + " logical pixels. Template " + configuredSlot() + ".");
    }
});
function invoke(id, w, slot) {
    if (operation || pending) return feedback("A Window Tools action is in progress.");
    const token = {desktop:workspace.currentDesktop, activity:workspace.currentActivity};
    pending = token;
    deadline.start();
    function safe(fn) {
        return value => {
            if (pending !== token) return;
            try {
                if (token.desktop !== workspace.currentDesktop || token.activity !== workspace.currentActivity)
                    throw Error("The desktop or activity changed. Repeat the action.");
                fn(value);
            } catch (e) { finish(token); feedback(e.message); }
        };
    }
    function done(message) { finish(token); if (message) feedback(message); }
    function execute() {
        if (id === "Reload") {
            token.reload = true;
            callDBus("org.kde.KWin","/KWin","org.kde.KWin","reconfigure");
            return;
        }
        if (id === "Clear") { selection = []; return done("Selection cleared."); }
        if (id === "Inspect") {
            const escaped = value => String(value).slice(0,55).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
            return done(selection.map((item,i) => (i+1) + ". " + escaped(item.caption)).join("\n") || "Selection empty.");
        }
        if (id === "Remove") {
            const at = selection.indexOf(w);
            if (at < 0) throw Error("This window is outside the selection.");
            selection.splice(at,1);
            return done("Removed slot " + (at+1) + ".");
        }
        if (id === "Add") {
            const why = problem(w);
            if (why) throw Error(why);
            const at = selection.indexOf(w);
            if (at >= 0) return done("Already selected in slot " + (at+1) + ".");
            if (selection.length >= 8) throw Error("Select up to eight windows.");
            selection.push(w);
            return done("Added window in slot " + selection.length + ".");
        }
        if (id === "Undo") { done(); return undo(); }
        if (id === "Side" || id === "Coding") {
            const windows = checkedSelection();
            const output = windows[0].output;
            const boxes = preset(id, windows.length, area(output), setting("Gap",8,0,64));
            done();
            return startLayout(windows, windows.map(() => output), boxes);
        }
        const args = [templateBus, "/Templates", templateBus, id];
        if (id !== "List") args.push(String(slot));
        const windows = id === "Save" || id === "Load" ? checkedSelection() : [];
        if (id === "Save") args.push(JSON.stringify({version:1, slots:windows.map(item => ({
            output:uniqueOutput(item.output.name).name, edges:normalize(item.frameGeometry,area(item.output),tolerance(item.output))
        }))}));
        args.push(safe(raw => {
            const reply = JSON.parse(raw);
            if (!reply.ok) throw Error(reply.error);
            if (id === "Load") {
                const slots = reply.value.slots;
                if (slots.length !== windows.length) throw Error("Template " + slot + " needs " + slots.length + " selected windows.");
                if (windows.some((item,i) => !item || item !== selection[i])) throw Error("Selection changed. Select the windows again.");
                const outputs = slots.map(item => uniqueOutput(item.output));
                const boxes = slots.map((item,i) => project(item.edges,area(outputs[i])));
                done();
                startLayout(windows,outputs,boxes);
            } else if (id === "List") done("Saved template slots: " + (reply.value.join(", ") || "none"));
            else done("Template " + slot + (id === "Delete" ? " deleted." : " saved."));
        }));
        callDBus.apply(null,args);
    }
    // Query only on explicit invocation. Choosing windows is also disabled
    // while a known automatic tiler owns placement.
    let remaining = tilers.length + 2;
    function ready() { if (--remaining === 0) execute(); }
    // A running KWin can outlive dpkg removal. The session bus tracks the
    // package-owned service file, independently of an already running helper.
    callDBus("org.freedesktop.DBus","/org/freedesktop/DBus","org.freedesktop.DBus",
        "ListActivatableNames", safe(names => {
            if (names.indexOf(templateBus) < 0) {
                callDBus("org.kde.KWin","/Scripting","org.kde.kwin.Scripting","unloadScript","org.kernova.windowtools");
                throw Error("Window Tools was removed. Reinstall the package to use it.");
            }
            ready();
        }));
    callDBus("org.freedesktop.ScreenSaver","/ScreenSaver","org.freedesktop.ScreenSaver","GetActive",
        safe(locked => { if (locked) { finish(token); return; } ready(); }));
    for (const name of tilers) {
        callDBus("org.kde.KWin","/Scripting","org.kde.kwin.Scripting","isScriptLoaded", name,
            safe(loaded => {
                if (loaded) throw Error("Active tiling script: " + name + ". Choose one in KWin Scripts.");
                ready();
            }));
    }
}
function configuredSlot() { return setting("TemplateSlot",1,1,8); }
for (const action of actions) {
    registerShortcut("org.kernova.windowtools." + action[0], "KERNOVA Window Tools: " + action[1],
        "", () => invoke(action[0], workspace.activeWindow, configuredSlot()));
}
registerUserActionsMenu(w => {
    const slot = configuredSlot();
    return {text:"KERNOVA Window Tools", items:actions.map(action => ({
        text:action[1] + (["Save","Load","Delete"].indexOf(action[0]) >= 0 ? " " + slot : ""),
        triggered:() => invoke(action[0],w,slot)
    }))};
});
// At most eight windows have listeners. A committed entry loses ownership
// permanently on subsequent geometry or context changes, even if moved back.
let history = [];
const verifier = new QTimer();
verifier.interval = 80;
function unregister(entry) {
    for (const link of entry.links) { try { link[0].disconnect(link[1]); } catch (_) {} }
    entry.links = [];
}
function retire() {
    history.forEach(unregister);
    history = [];
}
function watch(entry) {
    function connect(signal, fn) {
        signal.connect(fn);
        entry.links.push([signal, fn]);
    }
    const invalidate = () => { entry.lost = true; };
    const w = entry.w;
    for (const sig of [w.interactiveMoveResizeStarted, w.maximizedChanged, w.tileChanged,
        w.desktopsChanged, w.activitiesChanged, w.fullScreenChanged, w.minimizedChanged, w.shadeChanged]) {
        connect(sig, invalidate);
    }
    connect(w.frameGeometryChanged, () => {
        if (entry.applied && !operation) {
            if (!closeRect(w.frameGeometry, entry.applied, 0.001)) invalidate();
        } else if (entry.reached && !closeRect(w.frameGeometry, entry.expected, tolerance(w.output))) invalidate();
    });
}
function contextOK(e) {
    return !e.lost && e.w && !e.w.deleted && e.desktop === workspace.currentDesktop &&
        e.activity === workspace.currentActivity && [e.from, e.to].every(site =>
            workspace.screens.indexOf(site.output) >= 0 && closeRect(area(site.output), site.area));
}
function matches(e, site, box) {
    return contextOK(e) && !problem(e.w) && e.w.output === site.output && closeRect(e.w.frameGeometry, box,tolerance(site.output));
}
function makeEntry(w, output, target) {
    const why = problem(w);
    if (why) throw Error(why);
    const before = copyRect(w.frameGeometry);
    const from = {output:w.output, area:area(w.output)};
    const to = {output, area:area(output)};
    checkLocation(from.output, before, tolerance(from.output));
    checkFit(w, output, target);
    return {w, from, to, before, target, desktop:workspace.currentDesktop,
        activity:workspace.currentActivity, expected:target, reached:false, lost:false, links:[]};
}
function checkLocation(output, target, rounding) {
    if (!inside(target, area(output),rounding)) throw Error("Place the whole frame inside its output work area.");
    const cx = target.x + target.width / 2;
    const cy = target.y + target.height / 2;
    const owners = workspace.screens.filter(o => {
        const g = o.geometry;
        return cx >= g.x && cx < g.x + g.width && cy >= g.y && cy < g.y + g.height;
    });
    if (owners.length !== 1 || owners[0] !== output)
        throw Error("Separate overlapping outputs in Display Configuration before placing this frame.");
}
function checkFit(w, output, target, rounding = 0) {
    checkLocation(output, target, rounding);
    if (w.output !== output && !w.moveableAcrossScreens) throw Error("A window cannot move between these outputs.");
    const width = target.width - (w.frameGeometry.width - w.clientGeometry.width);
    const height = target.height - (w.frameGeometry.height - w.clientGeometry.height);
    if (width < w.minSize.width || height < w.minSize.height ||
        width > w.maxSize.width || height > w.maxSize.height) throw Error("A selected window's size limits do not fit this layout.");
}
function startLayout(windows, outputs, boxes) {
    const entries = windows.map((w,i) => {
        try {
            const entry = makeEntry(w, outputs[i], boxes[i]);
            entry.slot = i + 1;
            return entry;
        } catch (error) { throw Error("Slot " + (i + 1) + ": " + error.message); }
    });
    const changed = entries.filter(e => !matches(e,e.to,e.target));
    if (!changed.length) return feedback("Already arranged. Previous Undo retained.");
    retire();
    history = changed;
    history.forEach(watch);
    requestFrames("apply", changed, changed.length);
}
function requestFrames(mode, entries, total) {
    operation = {mode, entries, total, ticks:0, stable:0};
    for (const e of entries) {
        e.reached = false;
        e.expected = mode === "apply" ? e.target : e.before;
        try {
            if (contextOK(e)) {
                e.w.frameGeometry = copyRect(e.expected);
                e.reached = matches(e, mode === "apply" ? e.to : e.from, e.expected);
            }
        } catch (_) { e.lost = true; }
    }
    verifier.start();
}
function restorable(e) {
    if (!matches(e, e.to, e.applied || e.target)) return false;
    try { checkFit(e.w,e.from.output,e.before,tolerance(e.from.output)); } catch (_) { return false; }
    return true;
}
function undo() {
    if (!history.length) return feedback("No layout to undo in this session.");
    const entries = history.filter(restorable);
    if (!entries.length) {
        const count = history.length;
        retire();
        return feedback("Undo restored 0 of " + count + ". Windows or their work areas changed.");
    }
    requestFrames("undo", entries, history.length);
}
verifier.timeout.connect(() => {
    const op = operation;
    if (!op) return;
    const applying = op.mode === "apply";
    const arrived = op.entries.filter(e => matches(e, applying ? e.to : e.from, e.expected));
    arrived.forEach(e => { e.reached = true; });
    op.stable = arrived.length === op.entries.length ? op.stable + 1 : 0;
    if (++op.ticks < 18 && op.stable < 2) return;
    verifier.stop();
    operation = null;
    if (applying && op.stable >= 2) {
        for (const e of arrived) e.applied = copyRect(e.w.frameGeometry);
        return feedback("Layout applied to " + arrived.length + " changed windows.");
    }
    if (applying) {
        const owned = arrived.filter(restorable);
        if (owned.length) return requestFrames("rollback", owned, op.total);
        retire();
        return feedback("Layout incomplete. 0 of " + op.total + " changes verified for rollback. Inspect the windows.");
    }
    const restored = arrived.length;
    const count = op.total;
    const skipped = history.filter(e => arrived.indexOf(e) < 0).map(e => {
        if (!e.w || e.w.deleted) return e.slot + " (closed)";
        if (!contextOK(e)) return e.slot + " (window or work area changed)";
        return e.slot + " (geometry changed or refused)";
    });
    retire();
    feedback((op.mode === "undo" ? "Undo" : "Incomplete layout. Rollback") + " restored " +
        restored + " of " + count + " requested frames." + (skipped.length ? " Check slots: " + skipped.join(", ") : ""));
});
workspace.windowRemoved.connect(w => {
    selection = selection.filter(item => item !== w);
    for (const e of history) if (e.w === w) { e.lost = true; unregister(e); e.w = null; }
});
function invalidateContext() { for (const e of history) if (!contextOK(e)) e.lost = true; }
workspace.screensChanged.connect(invalidateContext);
workspace.currentDesktopChanged.connect(invalidateContext);
workspace.currentActivityChanged.connect(invalidateContext);
